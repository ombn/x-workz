package com.dev.devapp.test;

import com.dev.devapp.dao.IplPointsDAO;
import com.dev.devapp.dto.IplPointsDTO;

public class Tester {
	
	
	public static void main(String[] args) {
		
		
		IplPointsDTO dto  = new IplPointsDTO();
		dto.setIplId(2);
		dto.setIplTeamNames("Kings X11 punjab");
		dto.setCity("punjab");
		dto.setPoints(6);
		dto.setNoOfMatches(9);
		
		
		IplPointsDAO dao   =   new IplPointsDAO();
		dao.saveIplPoints(dto);
		
		
		
	}

}
