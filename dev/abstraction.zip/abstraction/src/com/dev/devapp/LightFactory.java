package com.dev.devapp;

public class LightFactory {
	
	
public static ISwitch getLight(String type)
    {
	
	if(type.equalsIgnoreCase("TubeLight"))
	{
		return new TubeLightImpl();
	}
		
 else if(type.equalsIgnoreCase("CFlBulb")) 
 { 
	 return new CFLBulbImpl(); 
	 }
		 
	else {
		System.out.println("Light not found");
	}
	return null;
	}

}
