package com.dev.devapp;

public class TubeLightImpl implements ISwitch{
	
	
	public TubeLightImpl() {
		System.out.println(this.getClass().getSimpleName()+"created");
	}

	@Override
	public void SOn() {
		System.out.println("Tube Light is turned On");
		
	}

	@Override
	public void Soff() {
		System.out.println("Tube Light is turned Off");
	}
	
	
	

}
