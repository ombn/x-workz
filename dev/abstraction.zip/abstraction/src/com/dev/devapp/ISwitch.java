package com.dev.devapp;

public interface ISwitch {
	
	public void SOn();
	public void Soff();
	
}
