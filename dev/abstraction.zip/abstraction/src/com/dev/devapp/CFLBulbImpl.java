package com.dev.devapp;

public class CFLBulbImpl implements ISwitch{
	
	public CFLBulbImpl() {
		System.out.println(this.getClass().getSimpleName()+" created");
	}

	@Override
	public void SOn() {
		System.out.println("CFl Bulb is turned On");		
	}

	@Override
	public void Soff() {
		System.out.println("CFl Bulb is turned Off");				
	}


}
