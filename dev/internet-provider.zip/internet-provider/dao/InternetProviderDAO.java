package com.dev.devapp.dao;

import com.dev.devapp.dto.InternetProviderDTO;

public interface InternetProviderDAO {
	
	public void save(InternetProviderDTO dto);
	public void fetchInternet(int internetId); 
	public void updateInternetProvider(String name , int internetId);
	
	

}
