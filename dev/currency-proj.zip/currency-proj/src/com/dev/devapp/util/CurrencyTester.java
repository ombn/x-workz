package com.dev.devapp.util;

import com.dev.devapp.dao.CurrencyDAO;
import com.dev.devapp.dao.CurrencyDAOImpl;
import com.dev.devapp.dto.CurrencyDTO;

public class CurrencyTester {

	public static void main(String[] args) {

		CurrencyDTO currencyDTO = new CurrencyDTO();
		currencyDTO.setCurrencyId(1);
		currencyDTO.setCurrencyName("rupee");
		currencyDTO.setCountry("INDIA");
		currencyDTO.setExchangeRateWRTUSDollar(73.34);

		CurrencyDAO currencyDAO = new CurrencyDAOImpl();
		currencyDAO.saveCurrency(currencyDTO);

	}

}
