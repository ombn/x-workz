package com.dev.devapp.dao;

import com.dev.devapp.dto.CurrencyDTO;

public interface CurrencyDAO {
	
	public void saveCurrency(CurrencyDTO currencyDTO);

}
